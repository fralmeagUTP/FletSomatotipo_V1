from sqlalchemy import create_engine, inspect
import os
from dotenv import load_dotenv

# Load env from the project root .env if possible, but we don't know where it is exactly relative to here.
# Assuming we run this from project root, and .env is there.
load_dotenv()

DB_HOST = os.getenv("DB_HOST", "localhost")
DB_USER = os.getenv("DB_USER", "root")
DB_PASS = os.getenv("DB_PASSWORD", "")
DB_PORT = os.getenv("DB_PORT", "3306")
DB_NAME = os.getenv("DB_NAME", "somatocarta_db") # Fallback to common name if missing

# Try to find .env manually if not loaded
if not os.getenv("DB_HOST"):
     # Look for .env in current folder or parents
     pass 

# Hardcoding connection string from what I saw earlier? No, I saw it uses os.getenv.
# I will try to read the .env file directly if this fails, but let's assume the user environment has them set 
# OR I can try to import them from src.backend.database if I set PYTHONPATH.

import sys
sys.path.append(os.getcwd())

try:
    from src.backend.database import engine
    
    inspector = inspect(engine)
    print("Connecting to database...")
    
    view_name = "CDRVistaValoracionCorporal"
    if inspector.has_table(view_name): # Views are treated as tables by has_table in some dialects, or use get_view_names
        print(f"Table/View '{view_name}' FOUND.")
        columns = inspector.get_columns(view_name)
        print("Columns:")
        for col in columns:
            print(f"- {col['name']} ({col['type']})")
    else:
        print(f"Table/View '{view_name}' NOT FOUND.")
        print("Available tables/views:", inspector.get_table_names() + inspector.get_view_names())

except Exception as e:
    print(f"Error: {e}")
